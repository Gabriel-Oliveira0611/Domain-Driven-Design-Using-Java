package br.com.fiap.HXF_API.exception;

public class RegistroNaoEncontradoException extends Exception {
    public RegistroNaoEncontradoException(String message) {
        super(message);
    }
}
